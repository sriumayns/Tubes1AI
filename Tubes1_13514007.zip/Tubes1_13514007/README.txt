Laporan ini terdiri dari tiga folder:

-Folder src berisi source code java dimana algoritma dan struktur data diimplementasikan

-Folder web_view berisi source code dan tools yang digunakan sebagai GUI

-Folder doc berisi Dokumentasi, teori, serta ujicoba hasil eksekusi
